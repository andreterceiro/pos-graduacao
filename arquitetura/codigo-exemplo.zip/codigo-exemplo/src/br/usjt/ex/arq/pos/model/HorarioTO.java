package br.usjt.ex.arq.pos.model;

import java.io.Serializable;
import java.util.Date;

public class HorarioTO implements Serializable{

	private Long id;
	private int diaMes;
	private Date entrada;
	private Date saida;
	private Long codigoEscala;
	
	public HorarioTO() {
	
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getDiaMes() {
		return diaMes;
	}

	public void setDiaMes(int diaMes) {
		this.diaMes = diaMes;
	}

	public Date getEntrada() {
		return entrada;
	}

	public void setEntrada(Date entrada) {
		this.entrada = entrada;
	}

	public Date getSaida() {
		return saida;
	}

	public void setSaida(Date saida) {
		this.saida = saida;
	}
	
	public void setCodigoEscala(Long codigoEscala) {
		this.codigoEscala = codigoEscala;
	}
	
	public Long getCodigoEscala() {
		return codigoEscala;
	}
	
	
}
