package br.usjt.ex.arq.pos.model.negocio.strategy;

import java.util.Date;

public class ValidarHorarioFinalSemana extends ValidarHorarioTrabalhoStrategy{
	

	/**
	 * Horario de trabalho durante a semana nao deve ultrapassar 6 horas
	 */
	public boolean validar(Date entrada, Date saida) {
		long lentrada = entrada.getTime();
		long lsaida = saida.getTime();
		
		long lHorasTrabalhadas = lsaida - lentrada;
		
		double horasTrab = (double)lHorasTrabalhadas / 1000 / 60 / 60;
		
		return (horasTrab <= 6);	
	}

}
