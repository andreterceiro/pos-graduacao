package br.usjt.ex.arq.pos.model.negocio;

import java.util.ArrayList;
import java.util.List;

import br.usjt.ex.arq.pos.model.CadastrarEscalaException;
import br.usjt.ex.arq.pos.model.EscalaTO;
import br.usjt.ex.arq.pos.model.dao.DaoFactoryDinamico;
import br.usjt.ex.arq.pos.model.dao.EscalaDAO;


public class EscalaTrabalho {
	
	private Long id;

	private int codigoMotorista;
	
	private int mes;
	
	private List<Horario> horarios;
	
	
	public EscalaTrabalho(){
		
	}
	
	public void inserirHorario(Horario h) {
		if (horarios == null) {
			horarios = new ArrayList<Horario>();
		}
		horarios.add(h);
	}
	
	public void salvar() throws CadastrarEscalaException{

		DaoFactoryDinamico factory = new DaoFactoryDinamico();
		EscalaDAO dao = factory.criarEscalaDAO();
		this.id = dao.persist(this.getDados());
	
		for (Horario h : this.horarios) {
			if (h != null && h.getDiaMes() > 0) {
				h.salvar(id);
			}
		}
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	public Long getId() {
		return id;
	}
	public void setCodigoMotorista(int codigoMotorista) {
		this.codigoMotorista = codigoMotorista;
	}
	public int getCodigoMotorista() {
		return codigoMotorista;
	}
	public void setMes(int mes) {
		this.mes = mes;
	}
	public int getMes() {
		return mes;
	}
	public void setHorarios(List<Horario> horarios) {
		this.horarios = horarios;
	}
	public List<Horario> getHorarios() {
		return horarios;
	}
	
	public EscalaTO getDados() {
		EscalaTO to = new EscalaTO();
		to.setCodigoMotorista(this.getCodigoMotorista());
		to.setId(this.getId());
		to.setMes(this.getMes());
		if (horarios != null) {
			for (Horario h : horarios) {
				to.adicionarHorario(h.getDados());
			}
		}
		
		return to;
	}
}
