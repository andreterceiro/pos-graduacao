package br.usjt.ex.arq.pos.controller;

import javax.swing.JButton;
import javax.swing.JTable;

public interface IEscala {

	public String getMesRef() ;
	public void setMesRef(String mesRef) ;
	public String getCodigoMotorista() ;
	public void setCodigoMotorista(String codigoMotorista) ;
	public String getNomeMotorista() ;
	public void setNomeMotorista(String nomeMotorista) ;
	public String getDiaMes() ;
	public void setDiaMes(String txtDiaMes) ;
	public String getEntrada() ;
	public void setEntrada(String txtEntrada) ;
	public String getSaida() ;
	public void setSaida(String txtSaida) ;
	public JTable getHorarios() ;
	public JButton getBtnPesquisarMotorista()  ;
	public JButton getBtnAddHorario() ;
	public JButton getBtnFinalizar() ;
}
