package br.usjt.ex.arq.pos.model;

public class CadastrarEscalaException extends Exception{

	public CadastrarEscalaException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CadastrarEscalaException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CadastrarEscalaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CadastrarEscalaException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
