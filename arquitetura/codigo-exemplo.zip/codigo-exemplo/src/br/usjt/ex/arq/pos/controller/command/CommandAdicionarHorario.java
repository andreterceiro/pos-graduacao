package br.usjt.ex.arq.pos.controller.command;

import java.util.Calendar;
import java.util.Random;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import br.usjt.ex.arq.pos.controller.IEscala;
import br.usjt.ex.arq.pos.model.negocio.EscalaTrabalho;
import br.usjt.ex.arq.pos.model.negocio.Horario;

public class CommandAdicionarHorario extends AbstractCommand{

	
	public void processar(IEscala callback, Object bo) {
		EscalaTrabalho escala = (EscalaTrabalho)bo;
		
		if (escala.getId() == null) {
			if (callback.getMesRef() == null
					|| callback.getMesRef().trim().equals("")) {
				JOptionPane.showMessageDialog(null,
						"Informe mês de referência");

			} else if (callback.getCodigoMotorista() == null
					|| callback.getCodigoMotorista().trim().equals("")) {
				JOptionPane.showMessageDialog(null,
						"Informe código do motorista");

			} else {
				escala.setId(new Long(1));	// estou usando sempre ID 1 pois e apenas exemplo
				escala.setCodigoMotorista(Integer.parseInt(callback
						.getCodigoMotorista()));
				escala.setMes(Integer.parseInt(callback.getMesRef()));
			}
		}
		if (escala != null){
			Calendar entrada = Calendar.getInstance();
			entrada.set(2011, Integer.parseInt(callback.getMesRef())-1,
					Integer.parseInt(callback.getDiaMes()),
					Integer.parseInt(callback.getEntrada().substring(0, 2)),
					Integer.parseInt(callback.getEntrada().substring(3, 5)));

			Calendar saida = Calendar.getInstance();
			saida.set(2011, Integer.parseInt(callback.getMesRef())-1,
					Integer.parseInt(callback.getDiaMes()),
					Integer.parseInt(callback.getSaida().substring(0, 2)),
					Integer.parseInt(callback.getSaida().substring(3, 5)));

			Horario h = new Horario(Integer.parseInt(callback.getDiaMes()),
					entrada.getTime(), saida.getTime());

			if (h.horarioValido()) {
				escala.inserirHorario(h);
				DefaultTableModel tb = (DefaultTableModel) callback
						.getHorarios().getModel();
				tb.addRow(new Object[] { callback.getDiaMes(),
						callback.getEntrada(), callback.getSaida() });
			} else {
				JOptionPane
						.showMessageDialog(null,
								"Horas trabalhadas inválida para a data informada.!!");
			}
		}
		
	}
}
