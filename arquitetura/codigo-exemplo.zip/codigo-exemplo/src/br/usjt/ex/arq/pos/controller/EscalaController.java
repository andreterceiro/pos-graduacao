package br.usjt.ex.arq.pos.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import br.usjt.ex.arq.pos.controller.command.AbstractCommand;
import br.usjt.ex.arq.pos.controller.command.CommandFactory;
import br.usjt.ex.arq.pos.model.CadastrarEscalaException;
import br.usjt.ex.arq.pos.model.negocio.EscalaTrabalho;
import br.usjt.ex.arq.pos.model.negocio.Horario;


public class EscalaController implements ActionListener {

	IEscala callback = null;

	EscalaTrabalho escala = null;

	public EscalaController(IEscala callback) {
		escala = new EscalaTrabalho();
		this.callback = callback;
	}

	public void actionPerformed(ActionEvent e) {
		AbstractCommand cmd = CommandFactory.criarCommand(e.getActionCommand());
		cmd.processar(callback, escala);
	}
	
}
