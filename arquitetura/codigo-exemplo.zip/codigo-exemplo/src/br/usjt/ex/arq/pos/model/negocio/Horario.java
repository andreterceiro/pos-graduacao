package br.usjt.ex.arq.pos.model.negocio;

import java.util.Date;

import br.usjt.ex.arq.pos.model.CadastrarEscalaException;
import br.usjt.ex.arq.pos.model.HorarioTO;
import br.usjt.ex.arq.pos.model.dao.DaoFactoryDinamico;
import br.usjt.ex.arq.pos.model.dao.HorariosDAO;
import br.usjt.ex.arq.pos.model.negocio.strategy.ValidarHorarioTrabalhoStrategy;

public class Horario {

	private Long id;
	private int diaMes;
	private Date entrada;
	private Date saida;

	public Horario() {

	}

	/**
	 * Funcionario pode trabalhar ate 8 horas por dia
	 * 
	 * @param diaSemana
	 * @param horaEntrada
	 * @param horaSaida
	 */
	public Horario(int diaMes, Date entrada, Date saida) {
		this.diaMes = diaMes;
		this.entrada = entrada;
		this.saida = saida;
	}

	public void salvar(Long codescala) throws CadastrarEscalaException {

		HorarioTO to = this.getDados();
		to.setCodigoEscala(codescala);

		DaoFactoryDinamico factory = new DaoFactoryDinamico();
		HorariosDAO dao = factory.criarHorarioDAO();
		this.id = dao.persist(to);

	}

	public boolean horarioValido() {
		ValidarHorarioTrabalhoStrategy validador = ValidarHorarioTrabalhoStrategy
				.criarEstrategia(entrada);
		return validador.validar(entrada, saida);
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getId() {
		return id;
	}

	public void setDiaMes(int diaMes) {
		this.diaMes = diaMes;
	}

	public int getDiaMes() {
		return diaMes;
	}

	public void setEntrada(Date entrada) {
		this.entrada = entrada;
	}

	public Date getEntrada() {
		return entrada;
	}

	public void setSaida(Date saida) {
		this.saida = saida;
	}

	public Date getSaida() {
		return saida;
	}

	public HorarioTO getDados() {
		HorarioTO to = new HorarioTO();
		to.setId(this.getId());
		to.setDiaMes(this.getDiaMes());
		to.setEntrada(this.getEntrada());
		to.setSaida(this.getSaida());

		return to;
	}

}
