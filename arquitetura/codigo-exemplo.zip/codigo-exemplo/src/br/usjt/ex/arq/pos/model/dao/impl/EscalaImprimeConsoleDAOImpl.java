package br.usjt.ex.arq.pos.model.dao.impl;

import br.usjt.ex.arq.pos.model.CadastrarEscalaException;
import br.usjt.ex.arq.pos.model.EscalaTO;
import br.usjt.ex.arq.pos.model.dao.EscalaDAO;

public class EscalaImprimeConsoleDAOImpl implements EscalaDAO{

	public Long persist(EscalaTO to)  throws CadastrarEscalaException{

		// aqui pode ser colocado o codigo para acessar um banco de dados especifico.
		// neste exemplo, estou apenas imprimindo os dados de Escala
		//
		System.out.println("=======================================");
		System.out.println("Motorista - " + to.getCodigoMotorista());
		System.out.println("Mes - " + to.getMes());
		
		return to.getId();
	}
}
