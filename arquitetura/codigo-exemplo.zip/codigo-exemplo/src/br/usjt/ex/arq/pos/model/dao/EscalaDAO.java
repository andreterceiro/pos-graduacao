package br.usjt.ex.arq.pos.model.dao;

import br.usjt.ex.arq.pos.model.CadastrarEscalaException;
import br.usjt.ex.arq.pos.model.EscalaTO;

public interface EscalaDAO {

	/**
	 * Grava um registro no banco e retorna o ID
	 * 
	 * @param to
	 * @return
	 */
	public Long persist(EscalaTO to) throws CadastrarEscalaException;
}
