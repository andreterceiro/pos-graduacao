package br.usjt.ex.arq.pos.controller.command;

import br.usjt.ex.arq.pos.controller.IEscala;

public class CommandPesquisarMotorista extends AbstractCommand {

	public void processar(IEscala callback, Object bo) {
		//
		// para efeito de teste, estou usando o mesmo motorista
		//
		callback.setNomeMotorista("João");
	}
}
