package br.usjt.ex.arq.pos.view;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import br.usjt.ex.arq.pos.controller.EscalaController;
import br.usjt.ex.arq.pos.controller.IEscala;

public class FormEscala extends JFrame implements IEscala{

	private static final long serialVersionUID = 1L;
	
	private JTable horarios = null;
	
	private JTextField txtMes;
	private JButton btnPesquisarMotorista;
	private JTextField txtCodigoMotorista;
	private JTextField txtNomeMotorista;
	
	private JButton btnAddHorario;
	private JTextField txtDiaMes;
	private JTextField txtEntrada;
	private JTextField txtSaida;
	
	private JButton btnFinalizar;
	
	public FormEscala() {
		EscalaController ec = new EscalaController(this);
		
		BorderLayout mainLayout = new BorderLayout(2,2);
		
		Container tela = getContentPane();
		tela.setLayout(mainLayout);
		
		txtMes = new JTextField(15);
		
		btnPesquisarMotorista = new JButton("pesquisar motorista");
		btnPesquisarMotorista.addActionListener(ec);
		btnPesquisarMotorista.setActionCommand("command.pesquisar.motorista");
		
		btnAddHorario = new JButton("adicionar");
		btnAddHorario.addActionListener(ec);
		btnAddHorario.setActionCommand("command.adicionar.horario");
		
		txtCodigoMotorista = new JTextField(15);
		txtNomeMotorista = new JTextField(40);
		txtDiaMes = new JTextField(15);
		txtEntrada = new JTextField(15);
		txtSaida = new JTextField(15);
		
		JPanel top = new JPanel();
		top.setLayout(new GridLayout(4,4));
		top.add(new JLabel("mês ref."));
		top.add(new JLabel("cod. motorista"));
		top.add(new JLabel("nome motorista"));
		top.add(new JLabel(""));

		top.add(txtMes);
		top.add(txtCodigoMotorista);
		top.add(txtNomeMotorista);
		top.add(btnPesquisarMotorista);

		top.add(new JLabel("dia mês"));
		top.add(new JLabel("entrada"));
		top.add(new JLabel("saída"));
		top.add(new JLabel(""));
		top.add(txtDiaMes);
		top.add(txtEntrada);
		top.add(txtSaida);
		top.add(btnAddHorario);
		
		JPanel botton = new JPanel();
		botton.setLayout(new GridLayout(1,2));
		btnFinalizar = new JButton("Finalizar");
		btnFinalizar.addActionListener(ec);
		btnFinalizar.setActionCommand("command.finalizar");
		
		botton.add(btnFinalizar);
		
		horarios = new JTable();
		horarios.setName("Escala");
		horarios.setModel(new DefaultTableModel(
            null,
            new String [] {
                "dia mês", "entrada", "saída"
            }
        ));
		tela.add(top,BorderLayout.NORTH);
		tela.add(horarios,BorderLayout.CENTER);
		tela.add(botton, BorderLayout.SOUTH);
		
		setSize(700, 400);
		setVisible(true);
	}
	
	//
	// implementacao dos metodos da interface IEscala para desacoplar 
	// o controlador do JFrame 
	//
	public String getMesRef() {
		return txtMes.getText();
	}

	public void setMesRef(String mesRef) {
		txtMes.setText(mesRef);
	}
	
	public String getCodigoMotorista() {
		return txtCodigoMotorista.getText();
	}

	public void setCodigoMotorista(String codigoMotorista) {
		this.txtCodigoMotorista.setText(codigoMotorista);
	}

	public String getNomeMotorista() {
		return txtNomeMotorista.getText();
	}

	public void setNomeMotorista(String nomeMotorista) {
		this.txtNomeMotorista.setText(nomeMotorista);
	}

	public String getDiaMes() {
		return txtDiaMes.getText();
	}

	public void setDiaMes(String txtDiaMes) {
		this.txtDiaMes.setText(txtDiaMes);
	}

	public String getEntrada() {
		return txtEntrada.getText();
	}

	public void setEntrada(String txtEntrada) {
		this.txtEntrada.setText(txtEntrada);
	}

	public String getSaida() {
		return txtSaida.getText();
	}

	public void setSaida(String txtSaida) {
		this.txtSaida.setText(txtSaida);
	}

	public JTable getHorarios() {
		return horarios;
	}

	public JButton getBtnPesquisarMotorista() {
		return btnPesquisarMotorista;
	}

	public JButton getBtnAddHorario() {
		return btnAddHorario;
	}

	public JButton getBtnFinalizar() {
		return btnFinalizar;
	}
	
	// ===============================================
	
	public static void main(String args[]) {
		FormEscala f = new FormEscala();
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE );
	}	
}
