package br.usjt.ex.arq.pos.model.dao;


import java.util.Properties;

public class DaoFactoryDinamico {
	
	private static Properties p = null;

	private static String C_CHAVE_ESCALA_DAO = "dao.escala.impl";
	private static String C_CHAVE_HORARIO_DAO = "dao.horario.impl";
	

	public EscalaDAO criarEscalaDAO() {
		return (EscalaDAO)obtemDao(C_CHAVE_ESCALA_DAO);
	}
	
	public HorariosDAO criarHorarioDAO(){
		return (HorariosDAO)obtemDao(C_CHAVE_HORARIO_DAO);
	}
	
	private static Object obtemDao(String chave) {
		try {
			// carrega arquivo de configuracao de DAOs caso ainda nao tenha sido
			// carregado
			//
			if (p == null) {
				p = new Properties();
				
				p.load(DaoFactoryDinamico.class.getResourceAsStream("dao.properties"));
			}

			// obtem a configuracao
			//
			String daoImpl = p.getProperty(chave);

			// carrega DAO dinamicamente
			//
			Class c = DaoFactoryDinamico.class.getClassLoader().loadClass(daoImpl);
			return c.newInstance();

		} catch (Exception e) {
			// lancando RuntimeException para nao precisar de tratamento
			// Nesse momento, ainda nao foi apresentado em sala de aula o modelo
			// de tratamento de erros do java.

			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}	
}
