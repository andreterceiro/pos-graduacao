package br.usjt.ex.arq.pos.controller.command;

import br.usjt.ex.arq.pos.controller.IEscala;

public abstract class AbstractCommand {

	public abstract void processar(IEscala callback, Object bo);
}
