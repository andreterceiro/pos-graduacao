package br.usjt.ex.arq.pos.controller.command;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import br.usjt.ex.arq.pos.controller.IEscala;
import br.usjt.ex.arq.pos.model.CadastrarEscalaException;
import br.usjt.ex.arq.pos.model.negocio.EscalaTrabalho;

public class CommandFinalizar extends AbstractCommand {

	public void processar(IEscala callback, Object bo) {
		JTable jt = callback.getHorarios();

		EscalaTrabalho escala = (EscalaTrabalho)bo;
		try {
			escala.salvar();
		} catch (CadastrarEscalaException e1) {
			JOptionPane.showMessageDialog(null, e1.getMessage());
		}
		DefaultTableModel dtm = (DefaultTableModel) jt.getModel();
		while (jt.getRowCount() > 0) {
			dtm.removeRow(0);
		}
		callback.setMesRef("");
		callback.setCodigoMotorista("");
		callback.setNomeMotorista("");
		callback.setEntrada("");
		callback.setSaida("");
		callback.setDiaMes("");

		escala = null;

	}

}
