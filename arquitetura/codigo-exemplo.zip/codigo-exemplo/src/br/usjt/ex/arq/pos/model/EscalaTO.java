package br.usjt.ex.arq.pos.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class EscalaTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3365860774101091027L;

	private Long id;

	private int codigoMotorista;
	
	private int mes;
	
	private List<HorarioTO> horarios = null;

	public void adicionarHorario (HorarioTO hto) {
		if(horarios == null){
			horarios = new ArrayList<HorarioTO>();
		}
		horarios.add(hto);
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getCodigoMotorista() {
		return codigoMotorista;
	}

	public void setCodigoMotorista(int codigoMotorista) {
		this.codigoMotorista = codigoMotorista;
	}

	public int getMes() {
		return mes;
	}

	public void setMes(int mes) {
		this.mes = mes;
	}

	public List<HorarioTO> getHorarios() {
		return horarios;
	}

	public void setHorarios(List<HorarioTO> horarios) {
		this.horarios = horarios;
	}
	
}
