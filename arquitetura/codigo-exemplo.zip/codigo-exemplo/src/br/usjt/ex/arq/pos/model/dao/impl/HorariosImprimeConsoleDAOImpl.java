package br.usjt.ex.arq.pos.model.dao.impl;

import br.usjt.ex.arq.pos.model.CadastrarEscalaException;
import br.usjt.ex.arq.pos.model.HorarioTO;
import br.usjt.ex.arq.pos.model.dao.HorariosDAO;

public class HorariosImprimeConsoleDAOImpl implements HorariosDAO {

	public Long persist(HorarioTO to)  throws CadastrarEscalaException{
		
		System.out.println("---------------------------------------");
		System.out.println("Dia do mês - " + to.getDiaMes());
		System.out.println("Entrada - " + to.getEntrada().getTime());
		System.out.println("Saida - " + to.getSaida().getTime());
			
		return to.getId();
	}
}
