package br.usjt.ex.arq.pos.controller.command;

import java.util.Properties;

/**
 * Implementação do padrão Factory para criar objetos do tipo AbstractCommand
 * @author Rogério A. Rondini
 *
 */
public class CommandFactory {

	private static Properties p = null;
	
	public static AbstractCommand criarCommand(String acao) {
		try {
			// carrega arquivo de configuracao de DAOs caso ainda nao tenha sido
			// carregado
			//
			if (p == null) {
				p = new Properties();
				
				p.load(CommandFactory.class.getResourceAsStream("command.properties"));
			}

			// obtem a configuracao
			//
			String command = p.getProperty(acao);

			// carrega Command dinamicamente
			//
			Class c = CommandFactory.class.getClassLoader().loadClass(command);
			return (AbstractCommand)c.newInstance();

		} catch (Exception e) {
			// lancando RuntimeException para nao precisar de tratamento
			// Nesse momento, ainda nao foi apresentado em sala de aula o modelo
			// de tratamento de erros do java.

			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}		
}
