package br.usjt.ex.arq.pos.model.dao;

import br.usjt.ex.arq.pos.model.CadastrarEscalaException;
import br.usjt.ex.arq.pos.model.HorarioTO;

public interface HorariosDAO {

	public Long persist(HorarioTO to)  throws CadastrarEscalaException;
}
