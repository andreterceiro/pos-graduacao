package br.usjt.ex.arq.pos.model.negocio.strategy;

import java.util.Calendar;
import java.util.Date;

public abstract class ValidarHorarioTrabalhoStrategy {

	/**
	 * Bloco de codigo estatico para inicializar o vetor de estrategias
	 * - Quando for sabado, ira obter a estrategia da posicao 6
	 * - Quando for domingo, ira obter a estrategia da posicao 0
	 * - Quando for segunda, ira obter a estrategia da posicao 1
	 * - ... e assim por diante...
	 * Portanto, 0 e 6 representam domingo e sabado respectivamente
	 */
	private static ValidarHorarioTrabalhoStrategy estrategias[] = 
		new ValidarHorarioTrabalhoStrategy[7];
	static {
		// Estrategias utilizadas para sabado e domingo
		//
		estrategias[0] = new ValidarHorarioFinalSemana();
		estrategias[6] = estrategias[0];

		// Estrategias utilizadas para semana
		//
		estrategias[1] = new ValidarHorarioDuranteSemana();
		estrategias[2] = estrategias[3] = estrategias[4] = estrategias[5] = estrategias[1];
	}

	public static ValidarHorarioTrabalhoStrategy criarEstrategia(Date dia) {
		Calendar c = Calendar.getInstance();
		c.setTime(dia);
		int diaDaSemana = c.get(Calendar.DAY_OF_WEEK);

		// utiliza "diaDaSemana -1" pois vetores em Java partem da posicao ZERO.
		// Portanto, ZERO representa o domingo.
		//
		return estrategias[diaDaSemana-1];
	}

	public abstract boolean validar(Date entrada, Date saida);
}
