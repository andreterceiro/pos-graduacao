Métricas de Software
=========================

Artigo do trabalho de Métricas de Software do curso de pós-graguação em [Engenharia de Software](http://www.usjt.br/prppg/lato/detalhe_curso.php?id=33) da [USJT](http://www.usjt.br/).
